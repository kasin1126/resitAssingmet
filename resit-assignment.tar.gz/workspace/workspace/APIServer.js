
var mysql = require('mysql');
var connection = mysql.createConnection({
    host: process.env.IP,
    user: 'resit-assignment',
    password: '',
    database: 'c9',
});


var restify = require('restify');
var request = require('request');
var fs = require('fs');
var mime = require('mime');
var assert = require('assert');


var server = restify.createServer();
server.use(restify.queryParser());
//server.use(restify.authorizationParser());
server.use(restify.bodyParser());


server.use( restify.CORS( {origins: ['*']}) );
server.use( restify.fullResponse() );


if ( typeof String.prototype.startsWith != 'function' ) {
  String.prototype.startsWith = function( str ) {
    return this.substring( 0, str.length ) === str;
  }
};


server.listen(8080, function(){
  console.log("incoming request being handled");
  
//search API
  server.get('/eventapi', function(req, res, next){
    console.log('Client are going to search some events');
    console.log('locationName: '+req.query.locationName);

    var googleKey="AIzaSyCPdS5B-RZMwIugu9tFKrxh1A_vmjS2fZ0";
    
    var keyword = req.query.keyword
    var locationName = req.query.locationName;
    var startdate = req.query.startdate;
    var enddate = req.query.enddate;
    var within = req.query.within;
    

    if (locationName == ""){
      res.send("Not a valid http request");
      res.end()
    }
    
    if(startdate == "" || enddate == ""){
      startdate = "Future";
    }else{
      var startdateformat = startdate.split('-');
      startdate = startdateformat[0]+startdateformat[1]+startdateformat[2]+"00"
      var enddateformat = enddate.split('-');
      enddate = "-"+enddateformat[0]+enddateformat[1]+enddateformat[2]+"00"
    }
    
    
    
    var locationURL = "https://www.googleapis.com/books/v1/volumes?q=flowers&orderBy=newest&key="+ googleKey;
   
    var query_event_string = ""
    
    
    var latlonresult = "";
    var eventresult;
    
    var eventcallback = function (error, response, body) {
      if (!error) {
        var eventJSON = JSON.parse(body);
        eventresult = eventJSON;
        res.setHeader('Content-Type', 'application/json');
        
        res.statusCode = 200;
        res.header('Access-Control-Allow-Origin','*')
        res.json(JSON.parse(body)); 
        res.send();
        res.end();

      }
    }
    
    
    var locationcallback = function (error, response, body) {
    if (!error && response.statusCode == 200) {
      
        var bodyJSON = JSON.parse(body);
        if(bodyJSON.hasOwnProperty('error_message')){
          res.send("Not a valid http request");
          res.end()
        }else if(bodyJSON.status == "ZERO_RESULTS"){
          res.send("No a valid location");
          res.end()
        }else{
          latlonresult = bodyJSON.results[0].geometry.location.lat + "," + bodyJSON.results[0].geometry.location.lng;
          console.log("lat&lng of location: " + latlonresult);
          query_event_string = {app_key: eventAPIKey, keywords : keyword, date: startdate+enddate, where: latlonresult, within : within};
          console.log(query_event_string);
          request.get({url:eventURL, qs: query_event_string}, eventcallback);
        }
      }
    };
    
    request.get({url: locationURL, qs: query_location_string}, locationcallback);

    //console.log('auth: '+JSON.stringify(req.authorization));
  });
//end of search API


//Registration
  server.post('/Registration', function(req,res,next){


    var data = req.body;
    var jsondata = JSON.parse(data)
    console.log(jsondata)

    if(!(jsondata.hasOwnProperty('username')&&jsondata.hasOwnProperty('password')&&jsondata.hasOwnProperty('Name'))){
      res.status(400);
      res.send();
      res.end();
    }else{
      

      
      var username = jsondata.username;
      var password = jsondata.password;
      var Name = jsondata.Name;
      
      var registeruser = {
        username:username,
        password:password,
        Name:Name
      };
      
      connection.query('INSERT INTO eventuser set ?', registeruser, function(error){
    if(error){
        console.log('fail to insert data');
        console.log(error);
        res.send(202);
        res.end();
    }else{
      console.log("Insert Success!")
      res.send();
      res.end();
    }
});
      
    }
    
});
//end of Registration

//Login
server.post('/loginprocess', function(req,res,next){

    var userrequest = req.body;
    var userrequestdata = JSON.parse(userrequest);
    
    console.log(userrequest);
    
    var username = userrequestdata.username;
    var password = userrequestdata.password;
    
    console.log (username + " " + password)

    
if(!(userrequestdata.hasOwnProperty('username') && userrequestdata.hasOwnProperty('password'))){
      res.status(400);
      res.send();
      res.end();
    }else{

      
      
      var queryString = 'Select * from eventuser'
      
      var loginsuccess = false;
      var result = { 
        username:'',
        Name:''
      };

      connection.query(queryString, function(err, rows, fields) {
      if (err) throw err;
 
        for (var i in rows) {
          if(username == rows[i].username && password == rows[i].password){
            loginsuccess = true;
            result.username = rows[i].username;
            result.Name = rows[i].Name;
          }
        }
        
        console.log(result);
        
        
        
        if(!loginsuccess){
          console.log('Invaild login');
          res.status(200);
          res.send(loginsuccess);
        }else{
          console.log('Vaild login');
          res.status(200);
          res.json(result);
          res.send();
        }
        res.end();
      });
      
    }
});
  
//end of Login  


//add book to DB

server.post('/addevent', function(req,res,next){
    var eventfromrequest = req.body;
    var eventjson = {};
    
    eventjson = JSON.parse(req.body);
    
    var username = eventjson.username;
    var eventlist = eventjson.events;
    


    for(var i = 0; i < eventlist.length; i++){
      
      var appendEvent = {
      username : username ,
      EventTitle : eventlist[i].title, 
      EventDescription : eventlist[i].description, 
      EventStartTime : eventlist[i].start_time, 
      EventStopTime : eventlist[i].stop_time, 
      EventLocation : eventlist[i].location
      }
      
      console.log(appendEvent);

      
      connection.query('INSERT INTO eventdata set ?', appendEvent,function(error) {
        if(error){
        console.log('fail to insert data');
        console.log(error);
        res.send(202);
        res.end();
        }
      });
    }
    
    
    console.log("Insert Success!")
    res.send();
    res.end();
    
      

    
});

//end of add book to DB  

//get book from DB
server.get('/getevent', function(req,res,next){
  
  console.log('get event from DB');

  var username ='';
  username = req.query.username;
  
  var queryString = "select * from eventdata where username = ?"

  var queryarray = [];
    
  connection.query(queryString, username, function(error, rows, fields) {
      if(error){
        console.log('fail to get data');
        console.log(error);
        res.send(202);
        
        res.end();
      }else{
      
        for (var i in rows) {
          var singleevent = {
            EventTitle : rows[i].EventTitle, 
            EventDescription : rows[i].EventDescription, 
            EventStartTime : rows[i].EventStartTime, 
            EventStopTime : rows[i].EventStopTime, 
            EventLocation : rows[i].EventLocation
          }
          queryarray.push(singleevent);
        }
        
        var result = {events : queryarray};
        console.log(result);
        res.json(result);
        res.send();
        res.end();
      }
      
    });
});
//end of get event from DB


//Delete event from DB
server.post('/deleteevent',function(req,res,next){
  
    console.log('Delete event from DB');

  
  var reqjson = JSON.parse(req.body);
  
  var username ='';
  username = reqjson.username;
  
  var eventsnumber = reqjson.eventsnumber;
  
  var queryString = "select * from eventdata where username = ?"
  var deleteString = "delete from eventdata where Itemid = ?"
  
  var queryarray = [];
    
  connection.query(queryString, username, function(error, rows, fields) {
      if(error){
        console.log('fail to get data');
        console.log(error);
        res.send(202);
        res.end();
      }else{
      
        for (var i in rows) {
          for(var j = 0; j < eventsnumber.length; j++ ){
            if(i == eventsnumber[j].eventnumber){
              queryarray.push(rows[i].Itemid)
            }
          }
        }

        for(var i = 0; i < queryarray.length; i++){
          connection.query(deleteString, queryarray[i], function(error, rows, fields) {
              if(error){
                console.log('Fail to delete data');
                console.log(error);
              }
          });
        }
        
      }
  });
  
  console.log("Delete Success!")
  res.send();
  res.end();
  
  
});
//end of Delete book from DB
});

