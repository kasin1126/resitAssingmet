// JavaScript Document
$(document).ready(function() {
	
	// Expand Panel
	$("#flip").mouseover(function(){
		$("#panelimages").slideDown("slow");
	
	});	
	$("#flip").click(function(){
		$("#panelimages").slideUp("slow");	
	});		
	//gooddetail1
	$("#flip1").mouseover(function(){
		$("#panelimages1").slideDown("slow");
	
	});	
	$("#flip1").click(function(){
		$("#panelimages1").slideUp("slow");	
	});		
	
	//gooddetail2
	$("#flip2").mouseover(function(){
		$("#panelimages2").slideDown("slow");
	
	});	
	
	$("#flip2").click(function(){
		$("#panelimages2").slideUp("slow");	
	});	
	//gooddetail3
	$("#flip3").mouseover(function(){
		$("#panelimages3").slideDown("slow");
	
	});	
	
	$("#flip3").click(function(){
		$("#panelimages3").slideUp("slow");	
	});		
	//gooddetail4
		$("#flip4").mouseover(function(){
		$("#panelimages4").slideDown("slow");
	
	});	
	
	$("#flip4").click(function(){
		$("#panelimages4").slideUp("slow");	
	});	
});
