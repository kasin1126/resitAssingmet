// JavaScript File

var userlogin = { username: '',
                password: ''
}

function submitform(){
    userlogin.username = document.getElementsByName('username')[0].value
    userlogin.password  = document.getElementsByName('password')[0].value

    postUserdata(userlogin);
}

function postUserdata(submituser){
    
var url = "https://sinwingchi-305cde-assignment-a09051995.c9users.io/loginprocess";

var loginuserjson = JSON.stringify(submituser);

console.log(loginuserjson);

var req = new XMLHttpRequest();
  req.open('post', url, false);
  req.send(loginuserjson);
  
  // now continue
  if (req.status == 200) {
     if(req.response == "false"){
        window.alert('Invalid Login');
     }else{
     console.log(req.response);
     var message = JSON.parse(req.response);
        console.log('message:')
        console.log(message.username + " : Login Success");
        console.log( "Welcome " + message.Name);
        document.cookie = "username=" + message.username
        window.location="UserMenu.html"
     }
  }
  else {
    throw Error(req.statusText || "Request failed");
  }
}

document.getElementsByName("Login")[0].onclick = submitform
